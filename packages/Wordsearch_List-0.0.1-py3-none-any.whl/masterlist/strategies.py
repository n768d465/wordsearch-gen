from collections import defaultdict
import re
import string


def default_strategy(scraped_html):
    ls = defaultdict(list)
    for a in scraped_html:
        if is_valid_word(a.text):
            ls[len(a.text)].append(a.text.lower())

    return ls


def food_strategy(scraped_html):
    ls = defaultdict(list)
    for f in scraped_html:
        for fo in f.next_sibling.split(", "):
            if is_valid_word(fo):
                ls[len(fo)].append(fo.lower())

    return ls


def is_valid_word(word):
    return len(word.split(" ")) == 1 and not re.search(f"[{string.punctuation}]", word)
