from .strategies import food_strategy, default_strategy

category_configs = [
    {
        "name": "Food",
        "strategy": food_strategy,
        "selector": lambda soup: soup.select("h2"),
        "source": {
            "url": "https://www.theproblemsite.com/alphabet-lists/food/foods",
            "verify": False,
        },
    },
    {
        "name": "Animals",
        "strategy": default_strategy,
        "selector": lambda soup: soup.select("tr td:nth-of-type(1)"),
        "source": {
            "url": "https://lib2.colostate.edu/wildlife/atoz.php?letter=ALL",
            "verify": False,
        },
    },
    {
        "name": "Countries",
        "strategy": default_strategy,
        "selector": lambda soup: soup.select("tr td:nth-of-type(2)"),
        "source": {
            "url": "https://www.worldometers.info/geography/alphabetical-list-of-countries/",
            "verify": False,
        },
    },
    {
        "name": "Christmas",
        "strategy": default_strategy,
        "selector": lambda soup: soup.select("div[class='wordlist-item']"),
        "source": {
            "url": "https://www.enchantedlearning.com/wordlist/christmas.shtml",
            "verify": False,
        },
    },
    {
        "name": "Obscure Words",
        "strategy": default_strategy,
        "selector": lambda soup: soup.select("a[class='word dynamictext']"),
        "source": {"url": "https://www.vocabulary.com/lists/270631"},
    },
]
