import json
import requests
import os

from .categories import category_configs
from bs4 import BeautifulSoup


path_to_json = os.path.dirname(__file__)
data_path = os.path.join(path_to_json, "data", "wordlist.json")


def build_category(config):
    req = requests.get(**config.get("source"))
    soup = BeautifulSoup(req.content, "html.parser")
    scraped_html = config.get("selector")(soup)
    category_data = config.get("strategy")(scraped_html)

    return category_data


def build_list():
    master_wordlist = {
        config["name"]: build_category(config) for config in category_configs
    }

    with open(data_path, "w") as outfile:
        json.dump(master_wordlist, fp=outfile, indent=2, sort_keys=True)

    return master_wordlist


def get_master_list(rebuild=False):
    if rebuild is True:
        return build_list()

    try:
        with open(data_path, "r") as infile:
            return json.load(infile)
    except Exception:
        return build_list()
